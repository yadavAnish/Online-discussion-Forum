<?php 
session_start();
include("database.php");
$reply = $_POST["reply"];
$discuss = $_POST["discuss_id"];
#echo $discuss;
$user = $_SESSION['username'];
#echo $username;
#$userid = $_USERID["userid"];
#echo $password;
$sql = "INSERT INTO reply (Reply, user, discussion_id) values ('$reply', '$user', '$discuss')";
#echo $sql;

if ($conn->query($sql) === TRUE) {
    #echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

header('Location: index.php');
?>
