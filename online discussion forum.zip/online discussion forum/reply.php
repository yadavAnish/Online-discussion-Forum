<!DOCTYPE html>
<html>
       <head>
             <title>Add Reply</title>
             <link rel="stylesheet" type="text/css" href="styles/styles.css">
             </head>
<body>
       
<form action="reply_code.php" method="post">
  <div class="container">
    <h1>Add Reply</h1>
    
    <hr>
    
    <label for="Username"><b>Title</b></label>
    <input type="text" placeholder="Title" name="title" required>
    
    <label for="email"><b>Add Content</b></label>
    <input type="text" placeholder="Content" name="content" required>

    <input type="submit" value="Add" class="Add">
  </div>
</html>
