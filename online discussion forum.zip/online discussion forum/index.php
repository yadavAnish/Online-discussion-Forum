<?php
session_start();
?>
<!DOCTYPE html>
<html>
       <head>
             <title>Online Discussion Forum</title>
             <link rel="stylesheet" type="text/css" href="styles/styles.css">
       </head>
       <body>
             <div id="wrpper">
			 <header><center>
				     <img src="images/logo.png" alt="logo"style="width:50%">
					 </center>
			     </header>
				 <nav>
				     <ul class="main menu">
					 <li><a href="index.php">Home</a></li>
					 <li><a href="Forum.html">Forum</a></li>
					 <li><a href="Contact us.html">Contact us</a></li>
					 <li><a href="register.php">Register</a></li>
					 <li><a href="login.php">Login</a></li>
					 <br>
					 <br>
					  <br>
					 <br>
					  <br>
					 <br>
					 <li><a href="discuss.php">Add discussion</a></li>
					 
					 
    				<div class="search" style="margin-left:75%; margin-top:20px;">
    					<input class="box" type="text" name="" placeholder="Search here...">
    					<input type="image" name="submit" src="images/searchlogo.png" class="btnn">

    				</div>

			 		
			 			
					    
    				</table>
    				<div class="card">
					  <h1><?php echo $_SESSION["username"];?></h1>
					</div>
    			</nav>
    <!--main body content -->
			 <img src="images/discussion.jpg" style="width: 100%">

			 	<?php
			 	include 'database.php';
			 	$sql="SELECT * from discuss, user WHERE discuss.user_id=user.userid";
			 	$result=$conn->query($sql);
			 	if(mysqli_num_rows($result)>0){
			 		while($row=mysqli_fetch_assoc($result)){

			 				$id=$row['id'];
			 				$title= $row['title'];
			 				$content=$row['content'];
			 				$usern = $row['username'];
			 				?>
			 				<tr>
			 					<td> <h1><?php echo $title ?><span style="font-size: 18px;"> - <?php echo $usern; ?></span></h1></td>
			 					<br>
			 					<td> <?php echo $content ?> </td> <p>
			 					<br>
			 					<p style="color: blue">Replies</p>
			 					<?php
			 					$sql1="SELECT * from reply where discussion_id = '$id'";
			 					$result1=$conn->query($sql1);
			 					if(mysqli_num_rows($result1)>0){
				 					while($row1=mysqli_fetch_assoc($result1)){
				 						$reply = $row1['Reply'];
				 						?>
				 						<p><?php echo $reply; ?> </h3>
				 						<?php
				 					}
				 					}
			 					?>

			 				</tr>
			 				<form action="reply_code.php" method="POST">
			 					<input type="text" name="reply">
			 					<input type="text" name="discuss_id" value="<?php echo $id; ?>" hidden>
			 					<input type="submit" name="Reply">
			 				</form>
			 				<hr>
			 				<?php
			 				
			 		}
			 	}

			 	?>
			 
			 
	<!--main body ends-->		 	
			 
			
			<footer>

			 	<table border="0" width="100%" height="20" cellpadding="0">
			 	<tr>
			 		<td width="30%" valign="top">
			 		<img src="images/address.png" height="25" width ="25"> 
			 		<h3 style="margin-left:8% ;margin-top: -20px;">Kandy Road, Malabe </h4>
			 		<img src="images/call.png" height="25" width ="25"> 
			 		<h4 style="margin-left:8%; margin-top: -20px;">+94-767745738</h4>
			 		<img src="images/mail.png" height="25" width ="25"> 
			 		<h4 style="margin-left:8%; margin-top: -20px;">onlineforumdiscussion@gmail.com </h4>
			 		</td>
			 
			 		<td width="30%" valign="top" align="center">
			 			<p style="margin-top: -1px; padding-left: -50px;">About Us: </p><br><br><br/>

			 			<form>
			 				<input type="text" placeholder="Enter Email..">
							<input type="submit" value="Subscribe" style="margin-left:-10px;"><br>
						</form>	


			 		</td>

			 			<td width="40%"  valign="top"  >
			 			<center>
			 				<h4 style="margin-top: -0px;">Quick link</h4>
					     	<ol class="main_menu " >
					     		<li><a href="index.php">Home</a></li>
						 		<li><a href="Contact us.html">Contact us</a></li>
								<li><a href="login.php">Login</a></li>
								<li><a href="Register.php">Register</a></li>
					 		</ol>
						</center>
						</td>

					</tr>

				</table>
				<hr color="white" width="80%">
				<center>
						Copyright &copy; 2019 All Rights Reserved by Online Discussion Forum.<br>
				</center>
			</footer>
        </body>
</html>