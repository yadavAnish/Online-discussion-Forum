<?php 
include("database.php");
session_start();

#$discussiono = $_POST["id"];
$title = $_POST["title"];
$content = $_POST["content"];
$user = $_SESSION['username'];

$sql1 = "SELECT * from  user where username='$user'";
$result1 = $conn->query($sql1);


if(mysqli_num_rows($result1)>0)
{
	while ($row=mysqli_fetch_assoc($result1)) {
		
		$userid=$row["userid"];
		#echo $userid;
		#$password=$row["password"];
	}
}


$sql = "INSERT INTO discuss (title,content,user_id) VALUES ( '$title', '$content', '$userid')";

if ($conn->query($sql) === TRUE) {
    #echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

header('Location: index.php');
?>