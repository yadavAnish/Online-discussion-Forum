

<!DOCTYPE html>
<html>
       <head>
             <title>Online Discussion Forum</title>
             <link rel="stylesheet" type="text/css" href="styles/styles.css">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
}

* {
  box-sizing: border-box;
}


/* style inputs and link buttons */
input,
.btn {
  width: 100%;
  padding: 12px;
  border: none;
  border-radius: 4px;
  margin: 5px 0;
  opacity: 0.85;
  display: inline-block;
  font-size: 17px;
  line-height: 20px;
  text-decoration: none; /* remove underline from anchors */
}

input:hover,
.btn:hover {
  opacity: 1;
}

/* add appropriate colors to fb, twitter and google buttons */
.fb {
  background-color: #3B5998;
  color: white;
}

.twitter {
  background-color: #55ACEE;
  color: white;
}

.google {
  background-color: #dd4b39;
  color: white;
}

/* style the submit button */
input[type=submit] {
  background-color: #4CAF50;
  color: white;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

/* Two-column layout */
.col {
  float: left;
  width: 50%;
  margin: auto;
  padding: 0 50px;
  margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* vertical line */
.vl {
  position: absolute;
  left: 50%;
  transform: translate(-50%);
  border: 2px solid #ddd;
  height: 175px;
}

/* text inside the vertical line */
.vl-innertext {
  position: absolute;
  top: 50%;
  transform: translate(-50%, -50%);
  background-color: #f1f1f1;
  border: 1px solid #ccc;
  border-radius: 50%;
  padding: 8px 10px;
}

/* hide some text on medium and large screens */
.hide-md-lg {
  display: none;
}

/* bottom container */
.bottom-container {
  text-align: center;
  background-color: #666;
  border-radius: 0px 0px 4px 4px;
}

/* Responsive layout - when the screen is less than 650px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 650px) {
  .col {
    width: 100%;
    margin-top: 0;
  }
  /* hide the vertical line */
  .vl {
    display: none;
  }
  /* show the hidden text on small screens */
  .hide-md-lg {
    display: block;
    text-align: center;
  }
}
</style>
</head>
<body>
             <div id="wrpper">
              
       <header><center>
             <img src="images/logo.png" alt="logo"style="width:50%">
           </center>
           </header>
         <nav>
             <ul class="main menu">
           <li><a href="index.php">Home</a></li>
         
           <li><a href="All Users.html">All Users</a></li>
           <li><a href="Contact us.html">Contact us</a></li>
           <li><a href="Login.php">Login</a></li>
           <li><a href="register.php">Register</a></li>
           
            <div class="search" style="margin-left:75%; margin-top:20px;">
              <input class="box" type="text" name="" placeholder="Search here...">
              <input type="image" name="submit" src="images/searchlogo.png" class="btnn">
            </div>
          <table width="100%" cellspacing="0px" cellpading="0px">
            <tr>
              <td>
            <button class="question">Add discussion</button>
                </td>

                <td>
            <button class="question">Trending Discussion</button>
                </td>

                <td>
            <button class="question">Old Discussion</button>
                </td>
              </tr>
            </table>
            <div class="card">
            <p><button>Profile</button></p>
          </div>
          </nav>

<div class="container">
  
    <div class="row">
      <h2 style="text-align:center">Login with Social Media or Manually</h2>
      <div class="vl">
        <span class="vl-innertext">or</span>
      </div>

      <div class="col">
        <a href="#" class="fb btn">
          <i class="fa fa-facebook fa-fw"></i> Login with Facebook
         </a>
        <a href="#" class="twitter btn">
          <i class="fa fa-twitter fa-fw"></i> Login with Twitter
        </a>
        <a href="#" class="google btn"><i class="fa fa-google fa-fw">
          </i> Login with Google+
        </a>
      </div>

      <div class="col">
        <div class="hide-md-lg">
          <p>Or sign in manually:</p>
        </div>
        <form action="login_code.php" method="post">
          <input type="text" name="username" placeholder="Username" required>
          <input type="password" name="password" placeholder="Password" required>
          <input type="submit" value="Login">
      </form>
      </div>
      
    </div>
  
</div>

<div class="bottom-container">
  <div class="row">
    <div class="col">
      <a href="#" style="color:white" class="btn">Sign up</a>
    </div>
    <div class="col">
      <a href="#" style="color:white" class="btn">Forgot password?</a>
    </div>
  </div>
</div>
<footer>

        <table border="0" width="100%" height="20" cellpadding="0">
        <tr>
          <td width="30%" valign="top">
          <img src="images/address.png" height="25" width ="25"> 
          <h3 style="margin-left:8% ;margin-top: -20px;">Kandy Road, Malabe </h4>
          <img src="images/call.png" height="25" width ="25"> 
          <h4 style="margin-left:8%; margin-top: -20px;">+94-767745738</h4>
          <img src="images/mail.png" height="25" width ="25"> 
          <h4 style="margin-left:8%; margin-top: -20px;">onlineforumdiscussion@gmail.com </h4>
          </td>
       
          <td width="30%" valign="top" align="center">
            <p style="margin-top: -1px; padding-left: -50px;">About Us: </p><br><br><br/>

            <form>
              <input type="text" placeholder="Enter Email..">
              <input type="submit" value="Subscribe" style="margin-left:-10px;"><br>
            </form> 


          </td>

            <td width="40%"  valign="top"  >
            <center>
              <h4 style="margin-top: -0px;">Quick link</h4>
                <ol class="main_menu " >
                  <li><a href="index.html">Home</a></li>
                
                <li><a href="Contact us.html">Contact us</a></li>
                <li><a href="Login.html">Login</a></li>
                <li><a href="Register.html">Register</a></li>
              </ol>
            </center>
            </td>

          </tr>

        </table>
        <hr color="white" width="80%">
        <center>
            Copyright &copy; 2019 All Rights Reserved by Online Discussion Forum.<br>
        </center>
      </footer>
</body>
</html>