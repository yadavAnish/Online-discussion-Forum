<!DOCTYPE html>
<html>
       <head>
             <title>Online Discussion Forum</title>
              <link rel="stylesheet" type="text/css" href="styles/styles.css">
			  <link rel="stylesheet" type="text/css" href="styles/style.css" >
              <link rel="stylesheet" type="text/css" href="styles/custom.css" >
       </head>
       <body>
             <div id="wrpper">
             <header><center>
                     <img src="images/logo.png" alt="logo"style="width:50%">
                     </center>
                 </header>
                 <nav>
                     <ul class="main menu">
                     <li><a href="index.html">Home</a></li>
                     <li><a href="Forum.html">Forum</a></li>
                     
                     <li><a href="Contact us.html">Contact us</a></li>
                     <li><a href="Login.html">Login</a></li>
                     <li><a href="Register.html">Register</a></li>
                     
                    <div class="search" style="margin-left:75%; margin-top:20px;">
                        <input class="box" type="text" name="" placeholder="Search here...">
                        <input type="image" name="submit" src="images/searchlogo.png" class="btnn">
                    </div>
                    <table width="100%" cellspacing="0px" cellpading="0px">
                        <tr>
                            <td>
                    <button class="question">Add discussion</button>
                            </td>

                            <td>
                    <button class="question">Trending Discussion</button>
                            </td>

                            <td>
                    <button class="question">Old Discussion</button>
                            </td>
                        </tr>
                    </table>
                    <div class="card">
                      <p><button>Profile</button></p>
                    </div>
                </nav>
			 
		<main class="contentArea">
            <div class="contentAreaInner small-canvas clearfix">
                <header class="page-header user-widget-wrap">
                    <h1>Create New Topic</h1>
                </header>

                <form action="discuss_code.php" method="post">
                    <div class="custom-select">
                        <span>Select a theme</span>
                        <select>
                            <option selected>Select a theme</option>
                            <option>Suono HTML</option>
                            <option>Gfashion WP</option>
                            <option>And Lorem Ipsum</option>
                        </select>
                    </div>
                    <div class="input-block">
                        <label for="giveTitle">Your Question</label>
                        <input id="giveTitle" type="text">
                    </div>
                    <div class="input-block">
                        <label for="writeDetails">Write to describe...</label>
                        <textarea id="writeDetails"></textarea>
                    </div>
                    <div class="custom-checkbox">
                        <input type="checkbox" id="followup-check">
                        <label for="followup-check">
                            <span></span>
                            Notify me of follow-up replies
                        </label>
                    </div>
                    <br>
                    <br>
                    <br>
                    <div class="text-center">
                        <input type="submit" value="Add" class="Add">
                    </div>
                </form>
            </div>
        </main>
        <footer>

                <table border="0" width="100%" height="20" cellpadding="0">
                <tr>
                    <td width="30%" valign="top">
                    <img src="images/address.png" height="25" width ="25"> 
                    <h3 style="margin-left:8% ;margin-top: -20px;">Kandy Road, Malabe </h4>
                    <img src="images/call.png" height="25" width ="25"> 
                    <h4 style="margin-left:8%; margin-top: -20px;">+94-767745738</h4>
                    <img src="images/mail.png" height="25" width ="25"> 
                    <h4 style="margin-left:8%; margin-top: -20px;">onlineforumdiscussion@gmail.com </h4>
                    </td>
             
                    <td width="30%" valign="top" align="center">
                        <p style="margin-top: -1px; padding-left: -50px;">About Us: </p><br><br><br/>

                        <form>
                            <input type="text" placeholder="Enter Email..">
                            <input type="submit" value="Subscribe" style="margin-left:-10px;"><br>
                        </form> 


                    </td>

                        <td width="40%"  valign="top"  >
                        <center>
                            <h4 style="margin-top: -0px;">Quick link</h4>
                            <ol class="main_menu " >
                                <li><a href="index.html">Home</a></li>
                               
                                <li><a href="Contact us.html">Contact us</a></li>
                                <li><a href="Login.html">Login</a></li>
                                <li><a href="Register.html">Register</a></li>
                            </ol>
                        </center>
                        </td>

                    </tr>

                </table>
                <hr color="white" width="80%">
                <center>
                        Copyright &copy; 2019 All Rights Reserved by Online Discussion Forum.<br>
                </center>
            </footer>
        </body>
</html>