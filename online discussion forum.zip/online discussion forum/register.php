<!DOCTYPE html>
<html>
       <head>
             <title>Online Discussion Forum</title>
             <link rel="stylesheet" type="text/css" href="styles/styles.css"> 
    <style>
body {
  font-family: Arial, Helvetica, sans-serif;
}

* {
  box-sizing: border-box;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: #6666ff;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
</head>
<body>
             <div id="wrpper">
       <header><center>
             <img src="images/logo.png" alt="logo"style="width:50%">
           </center>
           </header>
         <nav>
             <ul class="main menu">
           <li><a href="index.html">Home</a></li>
           <li><a href="Forum.html">Forum</a></li>
          
           <li><a href="Contact us.html">Contact us</a></li>
           <li><a href="Login.html">Login</a></li>
           <li><a href="Register.html">Register</a></li>
           
            <div class="search" style="margin-left:75%; margin-top:20px;">
              <input class="box" type="text" name="" placeholder="Search here...">
              <input type="image" name="submit" src="images/searchlogo.png" class="btnn">
            </div>
          <table width="100%" cellspacing="0px" cellpading="0px">
            <tr>
              <td>
            <button class="question">Add discussion</button>
                </td>

                <td>
            <button class="question">Trending Discussion</button>
                </td>

                <td>
            <button class="question">Old Discussion</button>
                </td>
              </tr>
            </table>
            <div class="card">
            <p><button>Profile</button></p>
          </div>
          </nav>


<form action="user.php" method="post">
  <div class="container">
    <h1>Register</h1>
    <p>Please fill in this form to create an account.</p>
    <hr>
    
    <label for="Username"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="username" required>
    
    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" required>

    <label for="psw-repeat"><b>Repeat Password</b></label>
    <input type="password" placeholder="Repeat Password" name="password_repeat" required>
    <hr>
    <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>

    <input type="submit" value="Register" class="registerbtn">
  </div>
  
  <div class="container signin">
    <p>Already have an account? <a href="#">Sign in</a>.</p>
  </div>
</form>
 <footer>

        <table border="0" width="100%" height="20" cellpadding="0">
        <tr>
          <td width="30%" valign="top">
          <img src="images/address.png" height="25" width ="25"> 
          <h3 style="margin-left:8% ;margin-top: -20px;">Kandy Road, Malabe </h4>
          <img src="images/call.png" height="25" width ="25"> 
          <h4 style="margin-left:8%; margin-top: -20px;">+94-767745738</h4>
          <img src="images/mail.png" height="25" width ="25"> 
          <h4 style="margin-left:8%; margin-top: -20px;">onlineforumdiscussion@gmail.com </h4>
          </td>
       
          <td width="30%" valign="top" align="center">
            <p style="margin-top: -1px; padding-left: -50px;">About Us: </p><br><br><br/>

            <form>
              <input type="text" placeholder="Enter Email..">
              <input type="submit" value="Subscribe" style="margin-left:-10px;"><br>
            </form> 


          </td>

            <td width="40%"  valign="top"  >
            <center>
              <h4 style="margin-top: -0px;">Quick link</h4>
                <ol class="main_menu " >
                  <li><a href="index.php">Home</a></li>
             
                <li><a href="Contact us.html">Contact us</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="register.php">Register</a></li>
              </ol>
            </center>
            </td>

          </tr>

        </table>
        <hr color="white" width="80%">
        <center>
            Copyright &copy; 2019 All Rights Reserved by Online Discussion Forum.<br>
        </center>
      </footer>
</body>
</html>