
<!DOCTYPE html>
<html>
       <head>
             <title>Add discussion</title>
             <link rel="stylesheet" type="text/css" href="styles/styles.css">
             </head>
<body>
       
<form action="discuss_code.php" method="post">
  <div class="container">
    <h1>Add Discussion</h1>
    <p>Please fill in this form to create an account.</p>
    <hr>
    
    <label for="Username"><b>Title</b></label>
    <input type="text" placeholder="Title" name="title" required>
    
    <label for="email"><b>Add Content</b></label>
    <input type="text" placeholder="Content" name="content" required>

    <input type="submit" value="Add" class="Add">
  </div>
</html>
