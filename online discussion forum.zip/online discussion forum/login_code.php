<?php 
include("database.php");


$username = $_POST["username"];
#echo $username;
$password = $_POST["password"];
#echo $password;
$sql = "SELECT * from  user where username='$username' AND password='$password' ";
#echo $sql;

$result = $conn->query($sql);


if(mysqli_num_rows($result)>0)
{
	while ($row=mysqli_fetch_assoc($result)) {
		
		$username=$row["username"];
		#$password=$row["password"];
		
		session_start();
		$_SESSION['username']=$username;
		#$_SESSION['username']=$username;
	}
	header("location:index.php");
}
else{
	echo "invalid username or password";
}

?>


